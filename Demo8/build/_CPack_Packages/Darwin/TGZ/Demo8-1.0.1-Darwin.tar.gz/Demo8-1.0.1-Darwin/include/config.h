#define HAVE_POW
